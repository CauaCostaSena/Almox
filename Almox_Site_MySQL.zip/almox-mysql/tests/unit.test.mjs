import {test} from 'node:test';
import assert from 'node:assert/strict';
import {priceCents,quantity,balance,productInput} from '../lib/rules.ts';
test('TU01 - preço: zero e negativo recusados; R$ 0,01 aceito',()=>{assert.throws(()=>priceCents('0'));assert.throws(()=>priceCents('-1'));assert.equal(priceCents('0,01'),1);assert.throws(()=>priceCents('1.001'));});
test('TU02 - quantidade positiva e inteira',()=>{for(const n of [0,-1,1.5,''])assert.throws(()=>quantity(n));assert.equal(quantity(1),1);assert.equal(quantity(0,true),0);});
test('TU03 - saída no limite e acima do saldo',()=>{assert.equal(balance(10,'saida',10),0);assert.throws(()=>balance(10,'saida',11));assert.equal(balance(10,'entrada',1),11);});
test('TU04 - nome e limites adicionais',()=>{assert.throws(()=>productInput({nome:' ',preco:1}));assert.throws(()=>quantity(1000001));assert.throws(()=>balance(1000000,'entrada',1));assert.equal(priceCents('1000000'),100000000);});
