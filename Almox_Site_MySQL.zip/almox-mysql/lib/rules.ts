export function priceCents(value: unknown): number {
 const s=String(value ?? '').trim().replace(',', '.');
 if(!/^\d+(\.\d{1,2})?$/.test(s)) throw new Error('Informe um preço válido com até duas casas decimais.');
 const n=Math.round(Number(s)*100);
 if(!Number.isSafeInteger(n)||n<1||n>100000000) throw new Error('O preço deve ser maior que zero e até R$ 1.000.000,00.');
 return n;
}
export function quantity(value: unknown, allowZero=false):number {
 const s=String(value ?? '').trim(); const n=Number(s);
 if(!/^\d+$/.test(s)||!Number.isSafeInteger(n)||n<(allowZero?0:1)||n>1000000) throw new Error(allowZero?'Informe uma quantidade inteira de 0 a 1.000.000.':'A quantidade movimentada deve ser inteira, positiva e até 1.000.000.');
 return n;
}
export function balance(stock:number,type:string,q:number):number {
 quantity(q); if(type!=='entrada'&&type!=='saida') throw new Error('Tipo de movimentação inválido.');
 const result=stock+(type==='entrada'?q:-q);
 if(result<0) throw new Error('Estoque insuficiente para esta saída.');
 if(result>1000000) throw new Error('O saldo não pode ultrapassar 1.000.000 de unidades.');
 return result;
}
export function productInput(b:Record<string,unknown>){
 const nome=String(b.nome??'').trim();
 if(nome.length<2||nome.length>100)throw new Error('O nome deve ter entre 2 e 100 caracteres.');
 return {nome,preco_centavos:priceCents(b.preco),quantidade:quantity(b.quantidade??0,true)};
}
