import {createServer} from 'node:http';
import {readFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import {createPool} from './db.mjs';
import {readStock,saveStock,InputError} from './service.mjs';
const root=path.resolve(fileURLToPath(new URL('../dist/',import.meta.url)));
const pool=createPool();
const types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.svg':'image/svg+xml','.png':'image/png','.woff2':'font/woff2'};
function json(res,status,data){res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end(JSON.stringify(data))}
async function body(req){let data='';for await(const part of req){data+=part;if(Buffer.byteLength(data)>16384)throw new InputError('Dados muito grandes.',413)}try{return JSON.parse(data)}catch{throw new InputError('JSON inválido.')}}
const server=createServer(async(req,res)=>{
 try{
  const url=new URL(req.url,'http://localhost');
  if(url.pathname==='/api/estoque'){
   if(req.method==='GET'){json(res,200,await readStock(pool));return;}
   if(req.method!=='POST'){json(res,405,{error:'Método não permitido.'});return;}
   if(!String(req.headers['content-type']).startsWith('application/json'))throw new InputError('Envie os dados em JSON.',415);
   const data=await body(req);const result=await saveStock(pool,data);json(res,data.action==='editar'?200:201,result);return;
  }
  if(req.method!=='GET'&&req.method!=='HEAD'){json(res,405,{error:'Método não permitido.'});return;}
  const requestPath=url.pathname==='/'?'/index.html':decodeURIComponent(url.pathname);
  const file=path.resolve(root,'.'+requestPath);
  if(!file.startsWith(root+path.sep)&&file!==path.join(root,'index.html')){json(res,403,{error:'Acesso negado.'});return;}
  try{const content=await readFile(file);res.writeHead(200,{'Content-Type':types[path.extname(file)]||'application/octet-stream','X-Content-Type-Options':'nosniff'});res.end(req.method==='HEAD'?undefined:content)}catch{json(res,404,{error:'Página não encontrada. Execute npm run build antes de iniciar.'})}
 }catch(e){if(e instanceof InputError){json(res,e.status,{error:e.message});return;}console.error(e.code??'',e.message);json(res,503,{error:'Não foi possível acessar o banco. Confira o serviço MySQL e a configuração do servidor.'});}
});
const port=Number(process.env.PORT||3000);
server.listen(port,'127.0.0.1',()=>console.log(`Almox: http://localhost:${port} | Banco MySQL: ${process.env.DB_NAME}`));
async function close(){server.close();await pool.end()};process.on('SIGINT',close);process.on('SIGTERM',close);
