import {randomUUID} from 'node:crypto';
import {productInput,quantity,balance} from '../lib/rules.ts';
import {transaction} from './db.mjs';
export class InputError extends Error {constructor(message,status=400){super(message);this.status=status}}
function valid(fn){try{return fn()}catch(e){throw new InputError(e.message)}}
async function lockProduct(c,id){const [rows]=await c.execute('SELECT id,quantidade FROM produtos WHERE id=? FOR UPDATE',[id]);if(!rows.length)throw new InputError('Produto não encontrado.',404);return rows[0]}
export async function readStock(pool){return transaction(pool,async c=>{
 const [produtos]=await c.query('SELECT * FROM produtos ORDER BY nome,id');
 const [movimentacoes]=await c.query('SELECT m.*,p.nome FROM movimentacoes m JOIN produtos p ON p.id=m.produto_id ORDER BY m.criado_em DESC,m.sequencia DESC');
 return {produtos,movimentacoes};
})}
export async function saveStock(pool,b){
 if(!b||typeof b!=='object'||Array.isArray(b))throw new InputError('Dados inválidos.');
 if(b.action==='produto'){
  const p=valid(()=>productInput(b));const id=randomUUID();
  return transaction(pool,async c=>{
   await c.execute('INSERT INTO produtos(id,nome,preco_centavos,quantidade) VALUES(?,?,?,?)',[id,p.nome,p.preco_centavos,p.quantidade]);
   if(p.quantidade>0)await c.execute("INSERT INTO movimentacoes(id,produto_id,tipo,quantidade,observacao) VALUES(?,?,'entrada',?,'Saldo inicial')",[randomUUID(),id,p.quantidade]);
   return {id};
  });
 }
 if(b.action==='editar'){
  const p=valid(()=>productInput({...b,quantidade:0}));const id=String(b.id??'');
  return transaction(pool,async c=>{await lockProduct(c,id);await c.execute('UPDATE produtos SET nome=?,preco_centavos=? WHERE id=?',[p.nome,p.preco_centavos,id]);return {ok:true}});
 }
 if(b.action==='movimentar'){
  const q=valid(()=>quantity(b.quantidade));const type=b.tipo;
  if(type!=='entrada'&&type!=='saida')throw new InputError('Tipo de movimentação inválido.');
  const note=String(b.observacao??'').trim();if(note.length>200)throw new InputError('A observação deve ter até 200 caracteres.');
  const productId=String(b.produto_id??'');const id=randomUUID();
  return transaction(pool,async c=>{
   const product=await lockProduct(c,productId);
   const next=valid(()=>balance(product.quantidade,type,q));
   await c.execute('UPDATE produtos SET quantidade=? WHERE id=?',[next,productId]);
   await c.execute('INSERT INTO movimentacoes(id,produto_id,tipo,quantidade,observacao) VALUES(?,?,?,?,?)',[id,productId,type,q,note]);
   return {id};
  });
 }
 throw new InputError('Operação inválida.');
}
